function A = PlotData(M)
hold on
plot(M(:,4))
plot(M(:,5))
plot(M(:,6))
legend('MMG 1', 'MMG 2', 'MMG 3')