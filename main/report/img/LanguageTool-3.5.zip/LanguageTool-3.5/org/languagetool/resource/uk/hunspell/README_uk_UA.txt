This is Ukrainian spelling dictionary based on dict_uk project (https://github.com/arysin/dict_uk)

Copyright (C) 2015
    Andriy Rysin

This dictionary is licensed under GPL 2.0 or above, LGPL 2.1 or above and MPL (Mozilla Public License) 1.1 licenses.
