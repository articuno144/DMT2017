_______________________________________________________________________________

   LEXIQUE FRANÇAIS, LISTE DES FORMES FLÉCHIES
   version 5.6
   
   Olivier R. - dicollecte<at>free<dot>fr
   Dicollecte: http://www.dicollecte.org/
   
   Licence :
   * MPL : Mozilla Public License
     version 2.0  --  http://www.mozilla.org/MPL/2.0/

   Pour participer à l’amélioration du lexique, allez sur :
   http://www.dicollecte.org/home.php?prj=fr
   
_______________________________________________________________________________

   NOTE
_______________________________________________________________________________

   Ce lexique a été généré à partir de la base de données de Dicollecte.
   Il contient les nouvelles et les anciennes graphies des mots concernés
   par les rectifications de l’orthographe proposées en 1990 par le Conseil
   supérieur à la langue française et par l’Académie française.
   
   À propos de la réforme orthographique de 1990 :
   http://www.renouvo.org/regles.php
   http://www.orthographe-recommandee.info/

_______________________________________________________________________________
